[1] 8
[1] "b_col1_1"
$motif_g
 [1] 1 0 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 1

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 9
[1] "b_col1_2"
$motif_g
 [1] 0 1 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 1 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 10
[1] "b_col1_3"
$motif_g
 [1] 0 0 1 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 1 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 11
[1] "b_col1_4"
$motif_g
 [1] 0 0 0 1 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 1 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 12
[1] "b_col1_5"
$motif_g
 [1] 0 0 0 0 1 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 1 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 13
[1] "b_col1_6"
$motif_g
 [1] 0 0 0 0 0 1 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 1 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 14
[1] "b_col1_7"
$motif_g
 [1] 0 0 0 0 0 0 1 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 1 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 15
[1] "b_col1_8"
$motif_g
 [1] 0 0 0 0 0 0 0 1 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 1 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 16
[1] "b_col1_9"
$motif_g
 [1] 0 0 0 0 0 0 0 0 1 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 1 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 17
[1] "b_col1_10"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 1 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 1 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 18
[1] "b_col1_11"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 0 1

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 1 0 0 0 0


[1] 8
[1] "c_2col_1"
$motif_g
 [1] 1 0 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 1

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 9
[1] "c_2col_2"
$motif_g
 [1] 0 1 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 1

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 10
[1] "c_2col_3"
$motif_g
 [1] 0 0 1 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 1 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 11
[1] "c_2col_4"
$motif_g
 [1] 0 0 0 1 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 1

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 12
[1] "c_2col_5"
$motif_g
 [1] 0 0 0 0 1 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 1 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 13
[1] "c_2col_6"
$motif_g
 [1] 0 0 0 0 0 1 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 1

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 14
[1] "c_2col_7"
$motif_g
 [1] 0 0 0 0 0 0 1 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 1 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 15
[1] "c_2col_8"
$motif_g
 [1] 0 0 0 0 0 0 0 1 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 1 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 16
[1] "c_2col_9"
$motif_g
 [1] 0 0 0 0 0 0 0 0 1 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 1 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 17
[1] "c_2col_10"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 1 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 1 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 18
[1] "c_2col_11"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 0 1

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 1


[1] 8
[1] "d_3col1_1col21"
$motif_g
 [1] 1 0 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 1

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 9
[1] "d_3col1_1col22"
$motif_g
 [1] 0 1 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 1 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 10
[1] "d_3col1_1col23"
$motif_g
 [1] 0 0 1 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 1 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 11
[1] "d_3col1_1col24"
$motif_g
 [1] 0 0 0 1 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 1 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 12
[1] "d_3col1_1col25"
$motif_g
 [1] 0 0 0 0 1 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 1 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 13
[1] "d_3col1_1col26"
$motif_g
 [1] 0 0 0 0 0 1 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 1 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 14
[1] "d_3col1_1col27"
$motif_g
 [1] 0 0 0 0 0 0 1 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 1 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 15
[1] "d_3col1_1col28"
$motif_g
 [1] 0 0 0 0 0 0 0 1 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 1 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 16
[1] "d_3col1_1col29"
$motif_g
 [1] 0 0 0 0 0 0 0 0 1 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 1 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 17
[1] "d_3col1_1col210"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 1 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 1 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 18
[1] "d_3col1_1col211"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 0 1

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 1 0 0


[1] 8
[1] "e_1col1_3col21"
$motif_g
 [1] 1 0 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 1

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 9
[1] "e_1col1_3col22"
$motif_g
 [1] 0 1 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 1 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 10
[1] "e_1col1_3col23"
$motif_g
 [1] 0 0 1 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 1 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 11
[1] "e_1col1_3col24"
$motif_g
 [1] 0 0 0 1 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 1 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 12
[1] "e_1col1_3col25"
$motif_g
 [1] 0 0 0 0 1 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 1 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 13
[1] "e_1col1_3col26"
$motif_g
 [1] 0 0 0 0 0 1 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 1 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 14
[1] "e_1col1_3col27"
$motif_g
 [1] 0 0 0 0 0 0 1 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 1 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 15
[1] "e_1col1_3col28"
$motif_g
 [1] 0 0 0 0 0 0 0 1 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 1 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 16
[1] "e_1col1_3col29"
$motif_g
 [1] 0 0 0 0 0 0 0 0 1 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 1 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 17
[1] "e_1col1_3col210"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 1 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 1 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 18
[1] "e_1col1_3col211"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 0 1

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 1 0


[1] 8
[1] "f_2col_1"
$motif_g
 [1] 1 0 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 1

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 9
[1] "f_2col_2"
$motif_g
 [1] 0 1 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 1 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 10
[1] "f_2col_3"
$motif_g
 [1] 0 0 1 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 1 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 11
[1] "f_2col_4"
$motif_g
 [1] 0 0 0 1 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 1 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 12
[1] "f_2col_5"
$motif_g
 [1] 0 0 0 0 1 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 1 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 13
[1] "f_2col_6"
$motif_g
 [1] 0 0 0 0 0 1 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 1

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 14
[1] "f_2col_7"
$motif_g
 [1] 0 0 0 0 0 0 1 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 1 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 15
[1] "f_2col_8"
$motif_g
 [1] 0 0 0 0 0 0 0 1 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 1 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 16
[1] "f_2col_9"
$motif_g
 [1] 0 0 0 0 0 0 0 0 1 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 1

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 17
[1] "f_2col_10"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 1 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 1 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 18
[1] "f_2col_11"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 0 1

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 1


[1] 8
[1] "g1"
$motif_g
 [1] 1 0 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 1

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 9
[1] "g2"
$motif_g
 [1] 0 1 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 1 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 10
[1] "g3"
$motif_g
 [1] 0 0 1 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 1 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 11
[1] "g4"
$motif_g
 [1] 0 0 0 1 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 1 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 12
[1] "g5"
$motif_g
 [1] 0 0 0 0 1 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 1 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 13
[1] "g6"
$motif_g
 [1] 0 0 0 0 0 1 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 1 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 14
[1] "g7"
$motif_g
 [1] 0 0 0 0 0 0 1 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 1 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 15
[1] "g8"
$motif_g
 [1] 0 0 0 0 0 0 0 1 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 1 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 16
[1] "g9"
$motif_g
 [1] 0 0 0 0 0 0 0 0 1 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 1 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 17
[1] "g10"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 1 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 1 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 18
[1] "g11"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 0 1

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 1 0 0


[1] 8
[1] "h1"
$motif_g
 [1] 1 0 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 1

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 9
[1] "h2"
$motif_g
 [1] 0 1 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 1 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 10
[1] "h3"
$motif_g
 [1] 0 0 1 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 1 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 11
[1] "h4"
$motif_g
 [1] 0 0 0 1 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 1 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 12
[1] "h5"
$motif_g
 [1] 0 0 0 0 1 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 1 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 13
[1] "h6"
$motif_g
 [1] 0 0 0 0 0 1 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 1 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 14
[1] "h7"
$motif_g
 [1] 0 0 0 0 0 0 1 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 1 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 15
[1] "h8"
$motif_g
 [1] 0 0 0 0 0 0 0 1 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 1 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 16
[1] "h9"
$motif_g
 [1] 0 0 0 0 0 0 0 0 1 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 1 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 17
[1] "h10"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 1 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 1 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 18
[1] "h11"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 0 1

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 1 0 0


[1] 8
[1] "j1"
$motif_g
 [1] 1 0 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 1

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 9
[1] "j2"
$motif_g
 [1] 0 1 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 1 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 10
[1] "j3"
$motif_g
 [1] 0 0 1 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 1 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 11
[1] "j4"
$motif_g
 [1] 0 0 0 1 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 1

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 12
[1] "j5"
$motif_g
 [1] 0 0 0 0 1 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 1

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 13
[1] "j6"
$motif_g
 [1] 0 0 0 0 0 1 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 1 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 14
[1] "j7"
$motif_g
 [1] 0 0 0 0 0 0 1 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 1

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 15
[1] "j8"
$motif_g
 [1] 0 0 0 0 0 0 0 1 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 1 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 16
[1] "j9"
$motif_g
 [1] 0 0 0 0 0 0 0 0 1 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 1 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 17
[1] "j10"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 1 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 1 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 18
[1] "j11"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 0 1

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 1


[1] 8
[1] "k1"
$motif_g
 [1] 1 0 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 1

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 9
[1] "k2"
$motif_g
 [1] 0 1 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 1 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 10
[1] "k3"
$motif_g
 [1] 0 0 1 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 1 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 11
[1] "k4"
$motif_g
 [1] 0 0 0 1 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 1 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 12
[1] "k5"
$motif_g
 [1] 0 0 0 0 1 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 1

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 13
[1] "k6"
$motif_g
 [1] 0 0 0 0 0 1 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 1 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 14
[1] "k7"
$motif_g
 [1] 0 0 0 0 0 0 1 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 1 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 15
[1] "k8"
$motif_g
 [1] 0 0 0 0 0 0 0 1 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 1 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 16
[1] "k9"
$motif_g
 [1] 0 0 0 0 0 0 0 0 1 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 1

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 17
[1] "k10"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 1 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 1

$motif_t$n18
[1] 0 0 0 0 0


[1] 18
[1] "k11"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 0 1

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 1


[1] 8
[1] "l1"
$motif_g
 [1] 1 0 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 1

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 9
[1] "l2"
$motif_g
 [1] 0 1 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 1 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 10
[1] "l3"
$motif_g
 [1] 0 0 1 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 1 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 11
[1] "l4"
$motif_g
 [1] 0 0 0 1 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 1 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 12
[1] "l5"
$motif_g
 [1] 0 0 0 0 1 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 1 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 13
[1] "l6"
$motif_g
 [1] 0 0 0 0 0 1 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 1 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 14
[1] "l7"
$motif_g
 [1] 0 0 0 0 0 0 1 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 1 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 15
[1] "l8"
$motif_g
 [1] 0 0 0 0 0 0 0 1 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 1 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 16
[1] "l9"
$motif_g
 [1] 0 0 0 0 0 0 0 0 1 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 1 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 17
[1] "l10"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 1 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 1 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 18
[1] "l11"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 0 1

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 1 0 0


[1] 8
[1] "m1"
$motif_g
 [1] 1 0 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 1

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 9
[1] "m2"
$motif_g
 [1] 0 1 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 1 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 10
[1] "m3"
$motif_g
 [1] 0 0 1 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 1 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 11
[1] "m4"
$motif_g
 [1] 0 0 0 1 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 1 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 12
[1] "m5"
$motif_g
 [1] 0 0 0 0 1 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 1 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 13
[1] "m6"
$motif_g
 [1] 0 0 0 0 0 1 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 1 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 14
[1] "m7"
$motif_g
 [1] 0 0 0 0 0 0 1 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 1 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 15
[1] "m8"
$motif_g
 [1] 0 0 0 0 0 0 0 1 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 1 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 16
[1] "m9"
$motif_g
 [1] 0 0 0 0 0 0 0 0 1 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 1 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 17
[1] "m10"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 1 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 1 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 18
[1] "m11"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 0 1

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 1 0 0


[1] 8
[1] "n1"
$motif_g
 [1] 1 0 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 1

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 9
[1] "n2"
$motif_g
 [1] 0 1 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 1 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 10
[1] "n3"
$motif_g
 [1] 0 0 1 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 1 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 11
[1] "n4"
$motif_g
 [1] 0 0 0 1 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 1 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 12
[1] "n5"
$motif_g
 [1] 0 0 0 0 1 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 1 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 13
[1] "n6"
$motif_g
 [1] 0 0 0 0 0 1 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 1 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 14
[1] "n7"
$motif_g
 [1] 0 0 0 0 0 0 1 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 1 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 15
[1] "n8"
$motif_g
 [1] 0 0 0 0 0 0 0 1 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 1 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 16
[1] "n9"
$motif_g
 [1] 0 0 0 0 0 0 0 0 1 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 1 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 17
[1] "n10"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 1 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 1 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 18
[1] "n11"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 0 1

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 1 0


[1] 8
[1] "o1"
$motif_g
 [1] 1 0 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 1

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 9
[1] "o2"
$motif_g
 [1] 0 1 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 1 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 10
[1] "o3"
$motif_g
 [1] 0 0 1 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 1 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 11
[1] "o4"
$motif_g
 [1] 0 0 0 1 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 1 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 12
[1] "o5"
$motif_g
 [1] 0 0 0 0 1 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 1 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 13
[1] "o6"
$motif_g
 [1] 0 0 0 0 0 1 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 1 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 14
[1] "o7"
$motif_g
 [1] 0 0 0 0 0 0 1 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 1 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 15
[1] "o8"
$motif_g
 [1] 0 0 0 0 0 0 0 1 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 1 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 16
[1] "o9"
$motif_g
 [1] 0 0 0 0 0 0 0 0 1 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 1 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 17
[1] "o10"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 1 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 1 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 18
[1] "o11"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 0 1

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 1 0


[1] 8
[1] "p1"
$motif_g
 [1] 1 0 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 1

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 9
[1] "p2"
$motif_g
 [1] 0 1 0 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 1 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 10
[1] "p3"
$motif_g
 [1] 0 0 1 0 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 1 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 11
[1] "p4"
$motif_g
 [1] 0 0 0 1 0 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 1 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 12
[1] "p5"
$motif_g
 [1] 0 0 0 0 1 0 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 1 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 13
[1] "p6"
$motif_g
 [1] 0 0 0 0 0 1 0 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 1 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 14
[1] "p7"
$motif_g
 [1] 0 0 0 0 0 0 1 0 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 1 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 15
[1] "p8"
$motif_g
 [1] 0 0 0 0 0 0 0 1 0 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 1 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 16
[1] "p9"
$motif_g
 [1] 0 0 0 0 0 0 0 0 1 0 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 1 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 17
[1] "p10"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 1 0

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 1 0 0 0

$motif_t$n18
[1] 0 0 0 0 0


[1] 18
[1] "p11"
$motif_g
 [1] 0 0 0 0 0 0 0 0 0 0 1

$motif_t
$motif_t$n8
[1] 0

$motif_t$n9
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n10
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n11
[1] 0 0 0 0 0 0

$motif_t$n12
[1] 0 0 0 0 0 0 0 0

$motif_t$n13
[1] 0 0 0 0 0 0 0 0

$motif_t$n14
 [1] 0 0 0 0 0 0 0 0 0 0

$motif_t$n15
 [1] 0 0 0 0 0 0 0 0 0 0 0 0

$motif_t$n16
[1] 0 0 0 0 0 0

$motif_t$n17
[1] 0 0 0 0 0 0 0 0 0

$motif_t$n18
[1] 0 0 0 1 0


